package com.thg.procurement.questionnaire.service.domain.enumeration;

/**
 * The ActionType enumeration.
 */
public enum ActionType {
    CREATED,
    UPDATED,
    DELETED,
}
