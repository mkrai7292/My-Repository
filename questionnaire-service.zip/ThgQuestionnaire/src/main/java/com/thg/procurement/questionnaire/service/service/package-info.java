/**
 * Service layer beans.
 */
package com.thg.procurement.questionnaire.service.service;
