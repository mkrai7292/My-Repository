/**
 * Data Transfer Objects.
 */
package com.thg.procurement.questionnaire.service.service.dto;
