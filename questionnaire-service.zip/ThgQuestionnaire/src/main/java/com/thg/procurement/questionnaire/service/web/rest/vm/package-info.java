/**
 * View Models used by Spring MVC REST controllers.
 */
package com.thg.procurement.questionnaire.service.web.rest.vm;
