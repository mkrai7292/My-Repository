/**
 * JPA domain objects.
 */
package com.thg.procurement.questionnaire.service.domain;
