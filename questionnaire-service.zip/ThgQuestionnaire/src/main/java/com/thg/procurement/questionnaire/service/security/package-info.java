/**
 * Spring Security configuration.
 */
package com.thg.procurement.questionnaire.service.security;
