/**
 * Spring Data JPA repositories.
 */
package com.thg.procurement.questionnaire.service.repository;
