package com.thg.procurement.questionnaire.service.cucumber;

import com.thg.procurement.questionnaire.service.IntegrationTest;
import io.cucumber.junit.platform.engine.Cucumber;

@Cucumber
@IntegrationTest
class CucumberIT {}
